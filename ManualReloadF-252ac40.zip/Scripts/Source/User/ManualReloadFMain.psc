Scriptname ManualReloadFMain extends Quest
{Manual reload (the F build): the game side. ManualReloadF.dll draws the magazine near the gun by itself;
this script only turns a dropped magazine into a real object, removes old ones and plays sounds.}

FormList Property MRF_Mags Auto Const      ; magazine items by kind: 0 standard, 1 large
FormList Property MRF_Sounds Auto Const    ; 0 magazine in, 1 magazine out, 2 slide back, 3 slide home, 4 put away
Static Property MRF_Round Auto Const       ; the cartridge drawn in the chamber / on the magazine (model set by the plugin)

int Property CmdSpawn = 1 AutoReadOnly
int Property CmdDelete = 2 AutoReadOnly
int Property CmdSound = 3 AutoReadOnly
int Property CmdRound = 4 AutoReadOnly
int Property CmdCasing = 5 AutoReadOnly
int Property RoundToken = -7 AutoReadOnly
int Property TimerPoll = 1 AutoReadOnly

bool Busy
int Ticks

Event OnInit()
	RegisterForRemoteEvent(Game.GetPlayer(), "OnPlayerLoadGame")
	StartTimer(0.1, TimerPoll)
EndEvent

Event Actor.OnPlayerLoadGame(Actor akSender)
	Busy = false
	StartTimer(0.1, TimerPoll)
EndEvent

Event OnTimer(int aiTimerID)
	if MRF_Mags && MRF_Sounds && !Busy
		Busy = true
		Handle()
		Ticks += 1
		if Ticks >= 40
			Ticks = 0
			Tidy()
		endif
		Busy = false
	endif
	StartTimer(0.03, TimerPoll)
EndEvent

Function Handle()
	int cmd = ManualReloadF.PollCommand()
	int n = 0
	while cmd != 0 && n < 8
		if cmd == CmdSpawn
			Spawn(ManualReloadF.CommandKind(), ManualReloadF.CommandPose(), ManualReloadF.CommandToken(), ManualReloadF.CommandScale())
		elseif cmd == CmdDelete
			ObjectReference ref = Game.GetForm(ManualReloadF.CommandRefID()) as ObjectReference
			; only this mod's own things: an id from before a load may name something else now
			if ref && IsOurs(ref)
				ref.Disable()
				ref.Delete()
			endif
		elseif cmd == CmdSound
			PlaySound(ManualReloadF.CommandKind())
		elseif cmd == CmdRound
			MakeRound()
		elseif cmd == CmdCasing
			Casing(ManualReloadF.CommandKind(), ManualReloadF.CommandPose(), ManualReloadF.CommandImpulse(), ManualReloadF.CommandToken())
		endif
		n += 1
		cmd = ManualReloadF.PollCommand()
	endwhile
EndFunction

bool Function IsOurs(ObjectReference ref)
	Form base = ref.GetBaseObject()
	if !base
		return false
	endif
	return MRF_Mags.Find(base) >= 0 || base == MRF_Round
EndFunction

Function Spawn(int kind, float[] pose, int token, float scale)
	if kind < 0 || kind >= MRF_Mags.GetSize()
		kind = 0
	endif
	ObjectReference mag = Game.GetPlayer().PlaceAtMe(MRF_Mags.GetAt(kind), 1, true, true, true)
	if !mag
		ManualReloadF.Notify(1)
		return
	endif
	; the plugin keeps drawing the magazine as it falls: the object appears where the drawn one is now
	float[] fresh = ManualReloadF.FreshPose(token)
	if fresh && fresh.Length == 6
		pose = fresh
	endif
	if scale > 0.05 && (scale < 0.99 || scale > 1.01)
		mag.SetScale(scale)   ; the gun is scaled (FRIK, a weapon mod): so is its magazine
	endif
	mag.SetPosition(pose[0], pose[1], pose[2])
	mag.SetAngle(pose[3], pose[4], pose[5])
	mag.Enable()
	int n = 0
	while !mag.Is3DLoaded() && n < 40
		Utility.Wait(0.02)
		n += 1
	endwhile
	fresh = ManualReloadF.FreshPose(token)
	if fresh && fresh.Length == 6
		mag.SetPosition(fresh[0], fresh[1], fresh[2])
	endif
	mag.SetMotionType(1, true)   ; a normal physical object: it lies on the ground, ROCK can hold it
	ManualReloadF.AddMag(mag, token)
EndFunction

; A case thrown out of the gun: a small physical object, pushed out of the port.
Function Casing(int kind, float[] pose, float[] impulse, int token)
	if kind < 0 || kind >= MRF_Mags.GetSize()
		return
	endif
	; not kept in the save for good: a case the plugin forgets (a load, a crash) is cleaned up by the game
	ObjectReference c = Game.GetPlayer().PlaceAtMe(MRF_Mags.GetAt(kind), 1, false, true, true)
	if !c
		return
	endif
	c.SetPosition(pose[0], pose[1], pose[2])
	c.SetAngle(pose[3], pose[4], pose[5])
	c.Enable()
	int n = 0
	while !c.Is3DLoaded() && n < 15
		Utility.Wait(0.02)
		n += 1
	endwhile
	c.SetMotionType(1, true)
	if impulse && impulse.Length == 4 && impulse[3] > 0.0
		c.ApplyHavokImpulse(impulse[0], impulse[1], impulse[2], impulse[3])
	endif
	ManualReloadF.AddMag(c, token)
EndFunction

; The round seen through the open slide: the plugin moves its 3D, the object only has to exist.
Function MakeRound()
	if !MRF_Round
		ManualReloadF.Notify(2)
		return
	endif
	ObjectReference r = Game.GetPlayer().PlaceAtMe(MRF_Round, 1, true, false, false)
	if r
		ManualReloadF.AddMag(r, RoundToken)
	else
		ManualReloadF.Notify(3)
	endif
EndFunction

; A magazine put away over the shoulder through ROCK lands in the inventory as an item. Its rounds are
; already back with the ammo you carry, so the item itself is taken away again.
Function Tidy()
	Actor player = Game.GetPlayer()
	int n = player.GetItemCount(MRF_Mags)
	if n > 0
		player.RemoveItem(MRF_Mags, n, true)
	endif
EndFunction

Function PlaySound(int index)
	if index >= 0 && index < MRF_Sounds.GetSize()
		Sound s = MRF_Sounds.GetAt(index) as Sound
		if s
			s.Play(Game.GetPlayer())
		else
			ManualReloadF.Notify(100 + index)
		endif
	endif
EndFunction
